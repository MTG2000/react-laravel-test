import Navbar from "./Navbar";
import Footer from "./Footer";

export { Navbar, Footer };
