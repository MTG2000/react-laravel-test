import { library } from "@fortawesome/fontawesome-svg-core";
import {
  faPhoneVolume,
  faAt,
  faFax,
  faArrowUp
} from "@fortawesome/free-solid-svg-icons";
library.add(faPhoneVolume, faAt, faFax, faArrowUp);
